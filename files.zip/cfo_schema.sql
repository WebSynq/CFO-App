-- CFO Conversations Table
-- Add this to your existing schema.sql or run as a migration

CREATE TABLE IF NOT EXISTS cfo_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'advisory',
    user_message TEXT NOT NULL,
    cfo_response TEXT,
    model_used TEXT,
    success INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cfo_session ON cfo_conversations(session_id);
CREATE INDEX IF NOT EXISTS idx_cfo_mode ON cfo_conversations(mode);
CREATE INDEX IF NOT EXISTS idx_cfo_created ON cfo_conversations(created_at);
