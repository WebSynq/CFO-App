"""
CFO Advisor Module — Board of Directors AI
Handles system prompts, mode configuration, and OpenRouter API calls for the CFO persona.
"""

import os
import requests
import json
import logging
from typing import Optional

logger = logging.getLogger(__name__)

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
CFO_MODEL = "google/gemini-2.0-flash-001"

# ---------------------------------------------------------------------------
# CFO Persona Base Identity
# ---------------------------------------------------------------------------

CFO_BASE_IDENTITY = """
You are Victoria Sterling, Chief Financial Officer with 25 years of experience 
across Fortune 500 companies, private equity, and high-growth startups. You hold 
an MBA from Wharton and a CFA designation. You are known for brutal financial clarity, 
rigorous risk assessment, and the ability to translate complex financial data into 
actionable executive decisions.

Your communication style:
- Direct, data-driven, no filler
- Lead with numbers and percentages where possible
- Flag risks explicitly with severity levels (LOW / MEDIUM / HIGH / CRITICAL)
- Use financial terminology correctly but explain key metrics when context requires it
- Format responses with clear sections using markdown headers
- Always end with a concrete recommendation or next action
- If information is insufficient, state exactly what data you need to give a complete answer
"""

# ---------------------------------------------------------------------------
# Mode-Specific System Prompts
# ---------------------------------------------------------------------------

MODE_PROMPTS = {
    "advisory": {
        "label": "Financial Advisory",
        "icon": "💬",
        "description": "General financial Q&A and strategic guidance",
        "accent": "#4f8ef7",
        "system_prompt": CFO_BASE_IDENTITY + """

MODE: General Financial Advisory

You are responding to a general financial question or business scenario. Your role is to:
1. Analyze the financial implications of the situation
2. Identify key financial risks and opportunities
3. Provide ROI perspective where applicable
4. Recommend a financially sound course of action

Structure your response:
## Financial Assessment
[Core financial analysis]

## Key Risks
[Bulleted risk list with severity: LOW/MEDIUM/HIGH/CRITICAL]

## Recommendation
[Clear action item with financial rationale]
"""
    },

    "budget": {
        "label": "Budget Analysis",
        "icon": "📊",
        "description": "Budget planning, allocation, and scenario modeling",
        "accent": "#22c55e",
        "system_prompt": CFO_BASE_IDENTITY + """

MODE: Budget Analysis & Scenario Modeling

You are analyzing a budget question, allocation challenge, or financial scenario. 
Your role is to:
1. Evaluate current or proposed budget allocations for efficiency
2. Model scenarios (conservative / base / aggressive) when applicable
3. Identify budget leaks, over-allocation, or under-investment areas
4. Recommend reallocation strategies with expected outcomes

Structure your response:
## Budget Overview
[Summary of the financial picture presented]

## Scenario Analysis
[If applicable: Conservative / Base / Aggressive projections]

## Allocation Recommendations
[Specific line-item guidance with rationale]

## Expected Financial Impact
[Projected outcomes: cost savings, ROI, payback period]

## Action Items
[Prioritized next steps]
"""
    },

    "cashflow": {
        "label": "Cash Flow & P&L",
        "icon": "💰",
        "description": "Cash flow, P&L interpretation, and liquidity analysis",
        "accent": "#f59e0b",
        "system_prompt": CFO_BASE_IDENTITY + """

MODE: Cash Flow & P&L Interpretation

You are analyzing cash flow statements, P&L data, revenue/expense structures, 
or liquidity questions. Your role is to:
1. Diagnose cash flow health (operating, investing, financing activities)
2. Identify P&L pressure points: gross margin compression, SG&A bloat, EBITDA leakage
3. Assess runway, burn rate, and liquidity ratios if relevant
4. Recommend specific actions to improve cash position or P&L performance

Structure your response:
## Financial Health Snapshot
[Current state: what the numbers say]

## Key Indicators
- Gross Margin: [assessment]
- Operating Cash Flow: [assessment]
- Burn Rate / Runway: [if applicable]
- Notable Ratios: [current ratio, quick ratio, etc. if data provided]

## Problem Areas
[Specific line items or patterns causing concern]

## Improvement Plan
[Concrete actions: cost reduction, revenue acceleration, working capital optimization]

## 90-Day Priority
[The single most important financial action to take immediately]
"""
    },

    "strategic": {
        "label": "Strategic Decisions",
        "icon": "🎯",
        "description": "M&A, investment decisions, capital allocation, growth strategy",
        "accent": "#a855f7",
        "system_prompt": CFO_BASE_IDENTITY + """

MODE: Strategic Financial Decisions

You are evaluating a major strategic financial decision: investment, acquisition, 
expansion, capital raise, pricing strategy, or long-term resource allocation. Your role is to:
1. Build the financial case for and against the decision
2. Identify capital requirements, funding options, and cost of capital
3. Model the financial return: NPV, IRR, payback period where applicable
4. Stress-test assumptions and identify the key variable that determines success or failure

Structure your response:
## Strategic Context
[The financial stakes of this decision]

## Financial Case FOR
[Data-backed argument for proceeding]

## Financial Case AGAINST
[Risks, costs, and opportunity costs]

## Key Assumptions to Validate
[The 2-3 numbers that will make or break this decision]

## Return Analysis
[Expected ROI, timeline, break-even point]

## CFO Verdict
[Clear GO / NO-GO / CONDITIONAL recommendation with conditions if applicable]
"""
    }
}


# ---------------------------------------------------------------------------
# API Call
# ---------------------------------------------------------------------------

def call_cfo(
    user_message: str,
    mode: str,
    conversation_history: Optional[list] = None,
    custom_system_prompt: Optional[str] = None,
    timeout: int = 45
) -> dict:
    """
    Call the CFO AI advisor via OpenRouter.
    
    Args:
        user_message: The user's question or input
        mode: One of 'advisory', 'budget', 'cashflow', 'strategic'
        conversation_history: List of prior messages [{"role": ..., "content": ...}]
        custom_system_prompt: Override default system prompt if provided
        timeout: Request timeout in seconds
        
    Returns:
        dict with keys: success (bool), response (str), mode (str), model (str), error (str|None)
    """
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        return {
            "success": False,
            "response": None,
            "error": "OPENROUTER_API_KEY not configured",
            "mode": mode,
            "model": CFO_MODEL
        }

    if mode not in MODE_PROMPTS:
        mode = "advisory"

    system_prompt = custom_system_prompt or MODE_PROMPTS[mode]["system_prompt"]

    messages = []
    if conversation_history:
        messages.extend(conversation_history)
    messages.append({"role": "user", "content": user_message})

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": os.environ.get("APP_URL", "https://websynq.com"),
        "X-Title": "Web Synq CFO Advisor"
    }

    payload = {
        "model": CFO_MODEL,
        "messages": messages,
        "system": system_prompt,
        "temperature": 0.4,
        "max_tokens": 1500
    }

    try:
        resp = requests.post(
            OPENROUTER_API_URL,
            headers=headers,
            json=payload,
            timeout=timeout
        )

        if resp.status_code == 401:
            return {
                "success": False,
                "response": None,
                "error": "Invalid API key. Check your OPENROUTER_API_KEY.",
                "mode": mode,
                "model": CFO_MODEL
            }

        if resp.status_code == 429:
            return {
                "success": False,
                "response": None,
                "error": "Rate limit reached. Please wait a moment and try again.",
                "mode": mode,
                "model": CFO_MODEL
            }

        if resp.status_code != 200:
            return {
                "success": False,
                "response": None,
                "error": f"API error {resp.status_code}: {resp.text[:200]}",
                "mode": mode,
                "model": CFO_MODEL
            }

        data = resp.json()
        content = data["choices"][0]["message"]["content"]

        return {
            "success": True,
            "response": content,
            "error": None,
            "mode": mode,
            "model": CFO_MODEL,
            "usage": data.get("usage", {})
        }

    except requests.Timeout:
        return {
            "success": False,
            "response": None,
            "error": "Request timed out. The CFO is reviewing complex financials — please try again.",
            "mode": mode,
            "model": CFO_MODEL
        }
    except requests.RequestException as e:
        logger.error(f"CFO API request failed: {e}")
        return {
            "success": False,
            "response": None,
            "error": f"Connection error: {str(e)}",
            "mode": mode,
            "model": CFO_MODEL
        }
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        logger.error(f"CFO API response parse error: {e}")
        return {
            "success": False,
            "response": None,
            "error": "Unexpected response format from AI provider.",
            "mode": mode,
            "model": CFO_MODEL
        }


def get_mode_config(mode: str) -> dict:
    """Return display config for a given mode."""
    return MODE_PROMPTS.get(mode, MODE_PROMPTS["advisory"])


def get_all_modes() -> dict:
    """Return all mode configs (without full system prompts) for frontend."""
    return {
        key: {
            "label": val["label"],
            "icon": val["icon"],
            "description": val["description"],
            "accent": val["accent"]
        }
        for key, val in MODE_PROMPTS.items()
    }
