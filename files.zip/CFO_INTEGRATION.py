# CFO Module — Integration Guide
# ──────────────────────────────────────────────────────────────────
# Add the following to your existing Board of Directors app.py
# ──────────────────────────────────────────────────────────────────


# ── 1. Import and register the blueprint (top of app.py) ──────────

from cfo_routes import cfo_bp

app.register_blueprint(cfo_bp)


# ── 2. Run the DB migration on startup ────────────────────────────
# Add this inside your init_db() function or call it at startup:

def init_cfo_db():
    """Create CFO conversations table if it doesn't exist."""
    db = sqlite3.connect(app.config["DATABASE"])
    db.executescript("""
        CREATE TABLE IF NOT EXISTS cfo_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            mode TEXT NOT NULL DEFAULT 'advisory',
            user_message TEXT NOT NULL,
            cfo_response TEXT,
            model_used TEXT,
            success INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_cfo_session ON cfo_conversations(session_id);
        CREATE INDEX IF NOT EXISTS idx_cfo_mode ON cfo_conversations(mode);
        CREATE INDEX IF NOT EXISTS idx_cfo_created ON cfo_conversations(created_at);
    """)
    db.commit()
    db.close()

# Call it during app initialization:
with app.app_context():
    init_db()       # your existing function
    init_cfo_db()   # new CFO tables


# ── 3. Verify DATABASE config is set ──────────────────────────────
# Your app.py should have this (adjust path as needed):
#   app.config["DATABASE"] = os.path.join(app.instance_path, "board.db")
# cfo_routes.py calls current_app.config["DATABASE"] — same key required.


# ── 4. Add CFO nav link to your existing index.html (optional) ────
# In your Board of Directors navigation, add:
#   <a href="/cfo">CFO Advisor</a>


# ── 5. GHL embed setup ────────────────────────────────────────────
# 1. Copy the contents of templates/cfo_embed.html
# 2. Replace "https://YOUR-RAILWAY-APP.railway.app" with your real Railway URL
# 3. Paste into a GHL Custom HTML block
# 4. Set CORS in app.py to allow your GHL subdomain:
#
#   from flask_cors import CORS
#   CORS(app, resources={
#       r"/cfo/*": {"origins": ["https://your-subdomain.gohighlevel.com"]}
#   })
#
# ⚠️ Never use wildcard CORS (*) in production.


# ── 6. Environment variables required ─────────────────────────────
# OPENROUTER_API_KEY  — your OpenRouter key (already in .env)
# APP_URL             — your Railway deployment URL (optional, used in API headers)


# ── 7. Routes added by this module ────────────────────────────────
# GET  /cfo/           → Full CFO advisor page (standalone)
# GET  /cfo/embed      → Lightweight embed page (for iFrame if needed)
# GET  /cfo/modes      → JSON: all mode configs
# POST /cfo/chat       → Main chat endpoint
# GET  /cfo/history    → Conversation history (query: session_id, mode, limit)
# DELETE /cfo/history/<id> → Delete a conversation entry


# ── 8. File structure ─────────────────────────────────────────────
# cfo_advisor.py           → AI persona, prompts, OpenRouter calls
# cfo_routes.py            → Flask blueprint (all /cfo/* routes)
# cfo_schema.sql           → DB schema (run once or add to init_db)
# templates/cfo.html       → Full standalone UI
# templates/cfo_embed.html → GHL-ready self-contained embed block
